<?php

namespace Drupal\server_configurator\Service;

use Drupal\server_configurator\Context\ConfiguratorContext;
use Drupal\server_configurator\Context\ConfiguratorContextResolver;

class ConfiguratorBootstrapManager {

  public function __construct(
    protected ConfiguratorContextResolver $contextResolver,
    protected ConfiguratorDrupalSettingsBuilder $settingsBuilder,
  ) {}

  /**
   * Attach frontend assets and settings to current page when needed.
   */
  public function attachToPage(array &$attachments, ?ConfiguratorContext $context = NULL): void {
    $context = $context ?: $this->contextResolver->resolveFromPage();

    if (!$context->shouldAttachFrontend()) {
      return;
    }

    $attachments['#attached']['library'][] = 'server_configurator/configurator';

    if ($context->isServerPage()) {
      $attachments['#attached']['drupalSettings']['serverConfigurator'] = $this->settingsBuilder->buildForCurrentServerPage();
      return;
    }

    if ($context->isMainConfigurator()) {
      $attachments['#attached']['drupalSettings']['serverConfigurator'] = $this->settingsBuilder->buildForMainConfiguratorForm();
    }
  }

  /**
   * Attach frontend assets and settings to Main Configurator form.
   */
  public function attachToMainForm(array &$form, ?ConfiguratorContext $context = NULL): void {
    $context = $context ?: $this->contextResolver->resolveFromPage();

    if (!$context->shouldAttachFrontend()) {
//      return;
    }

    $form['#attached']['library'][] = 'server_configurator/configurator';
    $form['#attached']['drupalSettings']['serverConfigurator'] = $this->settingsBuilder->buildForMainConfiguratorForm();
  }

}
