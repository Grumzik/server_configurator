<?php

namespace Drupal\server_configurator\Repository;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\NodeInterface;

/**
 * Repository for server nodes used by the main configurator.
 */
final class ServerRepository {

  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManager,
  ) {}

  /**
   * Finds server nodes based on compatible platform IDs.
   *
   * @param int[] $platformIds
   *   Platform node IDs.
   *
   * @return \Drupal\node\NodeInterface[]
   *   Server nodes keyed by node ID.
   */
  public function findServersByPlatformIds(array $platformIds): array {
    if (empty($platformIds)) {
      return [];
    }

    $query = $this->entityTypeManager
      ->getStorage('node')
      ->getQuery()
      ->accessCheck(TRUE)
      ->condition('type', 'server')
      ->condition('status', NodeInterface::PUBLISHED)
      ->condition('field_platform', $platformIds, 'IN')
      ->sort('title', 'ASC');

    $serverIds = $query->execute();
    if (empty($serverIds)) {
      return [];
    }

    return $this->entityTypeManager
      ->getStorage('node')
      ->loadMultiple($serverIds);
  }

  /**
   * Builds select options from server nodes.
   *
   * @param \Drupal\node\NodeInterface[] $servers
   *   Server nodes.
   *
   * @return array<int, string>
   *   Select options: nid => title.
   */
  public function buildOptions(array $servers): array {
    $options = [];

    foreach ($servers as $server) {
      if ($server instanceof NodeInterface) {
        $options[(int) $server->id()] = $server->label();
      }
    }

    return $options;
  }

}
